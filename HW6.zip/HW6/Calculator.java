package Calc;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.application.Application;
import javafx.beans.binding.Bindings;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.value.WritableObjectValue;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;

public class Calculator extends Application {
    public DoubleProperty value = new SimpleDoubleProperty();
    public static String number = "";
    public static int num1 , num2;
    public static double myresult;
    public static char operator;
    //public static TextField Result; //= new TextField();
    public boolean operand1 = true;
    @Override
    public void start(Stage primaryStage) {
        FlowPane pane = new FlowPane();
        pane.setAlignment(Pos.CENTER);
        pane.setPadding(new Insets ( 30 , 20 , 30 , 20));
        pane.setHgap(5);
        pane.setVgap(5);
        
        //TextField b = new TextField("input text"); 	
        Button seven = new Button("7");           
        Button eight = new Button("8");
        Button nine = new Button("9");
        Button plus = new Button("+");

            seven.setMinSize(80, 80);
            eight.setMinSize(80, 80);
            nine.setMinSize(80, 80);
            plus.setMinSize(80, 80);
    //pane.getChildren().add(b);
    pane.getChildren().add(seven);
        sevenHandler handler7 = new sevenHandler();
        seven.setOnAction(handler7);
    pane.getChildren().add(eight);
        eightHandler handler8 = new eightHandler();
        eight.setOnAction(handler8);
    pane.getChildren().add(nine);
        nineHandler handler9 = new nineHandler();
        nine.setOnAction(handler9);
    pane.getChildren().add(plus);
        plusHandler handlerplus = new plusHandler();
        plus.setOnAction(handlerplus);

        Button four = new Button("4");
        Button five = new Button("5");
        Button six = new Button("6");
        Button minus = new Button("-");

            four.setMinSize(80, 80);
            five.setMinSize(80, 80);
            six.setMinSize(80, 80);
            minus.setMinSize(80, 80);

    pane.getChildren().add(four);
        fourHandler handler4 = new fourHandler();
        four.setOnAction(handler4);
    pane.getChildren().add(five);
        fiveHandler handler5 = new fiveHandler();
        five.setOnAction(handler5);
    pane.getChildren().add(six);
        sixHandler handler6 = new sixHandler();
        six.setOnAction(handler6);
    pane.getChildren().add(minus);
        minusHandler handlerminus = new minusHandler();
        minus.setOnAction(handlerminus);

        Button three = new Button("3");
        Button two = new Button("2");
        Button one = new Button("1");
        Button multiply = new Button("*");

            three.setMinSize(80, 80);
            two.setMinSize(80, 80);
            one.setMinSize(80, 80);
            multiply.setMinSize(80, 80);

    pane.getChildren().add(one);
        oneHandler handler1 = new oneHandler();
        one.setOnAction(handler1);
    pane.getChildren().add(two);
        twoHandler handler2 = new twoHandler();
        two.setOnAction(handler2);
    pane.getChildren().add(three);
        threeHandler handler3 = new threeHandler();
        three.setOnAction(handler3);
    pane.getChildren().add(multiply);
        multiplyHandler handlermultiply = new multiplyHandler();
        multiply.setOnAction(handlermultiply);

        Button zero = new Button("0");
        Button equal = new Button("=");
        Button devision = new Button("/");
        Button EE = new Button ("EE");

            zero.setMinSize(80, 80);
            equal.setMinSize(80, 80);
            devision.setMinSize(80, 80);
            EE.setMinSize(80, 80);

    pane.getChildren().add(EE);
        EEHandler handlerEE = new EEHandler();
        EE.setOnAction(handlerEE);
    pane.getChildren().add(zero);
        zeroHandler handler0 = new zeroHandler();
        zero.setOnAction(handler0);
    pane.getChildren().add(equal);
        equalHandler handlerequal = new equalHandler();
        equal.setOnAction(handlerequal);
    pane.getChildren().add(devision);
        devisionHandler handlerdevision = new devisionHandler();
        devision.setOnAction(handlerdevision);

    Scene scene = new Scene(pane);
    primaryStage.setTitle("Calculator");
    primaryStage.setScene(scene);
    primaryStage.show();
    }
    public static void main (String[] args) {
    	Application.launch(args);  
    }
}
class zeroHandler extends Calculator implements EventHandler<ActionEvent>{
        @Override
    public void handle(ActionEvent e){
        	number += "0";
        	System.out.print("0");
    }
}
class oneHandler extends Calculator implements EventHandler<ActionEvent>{
        @Override
    public void handle(ActionEvent e){
        number += "1";
        System.out.print("1");
    }
}           
class twoHandler extends Calculator implements EventHandler<ActionEvent>{
        @Override
    public void handle(ActionEvent e){
        	number += "2";
        	System.out.print("2");
    }   
}
class threeHandler extends Calculator implements EventHandler<ActionEvent>{
        @Override
    public void handle(ActionEvent e){
        	number += "3";
            System.out.print("3");
    }
}           
class fourHandler extends Calculator implements EventHandler<ActionEvent>{
        @Override
    public void handle(ActionEvent e){
        	number += "4";
            System.out.print("4");
    }
}
class fiveHandler extends Calculator implements EventHandler<ActionEvent>{
        @Override
    public void handle(ActionEvent e){
        	number += "5";
            System.out.print("5");
    }
}                   
class sixHandler extends Calculator implements EventHandler<ActionEvent>{
        @Override
    public void handle(ActionEvent e){
        	number += "6";
            System.out.print("6");
    }
}                       
class sevenHandler extends Calculator implements EventHandler<ActionEvent>{
        @Override
    public void handle(ActionEvent e){
        	number += "7";
            System.out.print("7");
    }
}                           
class eightHandler extends Calculator implements EventHandler<ActionEvent>{
        @Override
    public void handle(ActionEvent e){
        	number += "8";
            System.out.print("8");
    }
}                               
class nineHandler extends Calculator implements EventHandler<ActionEvent>{
        @Override
    public void handle(ActionEvent e){
        	number += "9";
            System.out.print("9");
    }
}                                   
class plusHandler extends Calculator implements EventHandler<ActionEvent>{
        @Override
    public void handle(ActionEvent e){
        num1 = Integer.parseInt(number);
        number = "";
        System.out.print("+");
        operator = '+';
    }
}                                       
class minusHandler extends Calculator implements EventHandler<ActionEvent>{
        @Override
    public void handle(ActionEvent e){
        	num1 = Integer.parseInt(number);
        	number = "";
        	System.out.print("-");
        	operator = '-';
    }
}                                           
class multiplyHandler extends Calculator implements EventHandler<ActionEvent>{
        @Override
    public void handle(ActionEvent e){
        System.out.print("*");
        num1 =  Integer.parseInt(number);
        number = "";
        operator = '*';
    }
}
class devisionHandler extends Calculator implements EventHandler<ActionEvent>{
        @Override
    public void handle(ActionEvent e){
        	num1 = Integer.parseInt(number);
        	number = "";
        	System.out.print("/");
        	operator = '/';
    }
}                                                   
class equalHandler extends Calculator implements EventHandler<ActionEvent>{
        @Override
    public void handle(ActionEvent e){
        //System.out.print("=");
        	num2 = Integer.parseInt(number);
        	number = "";
        	if(operator == '+' )
        		myresult = num1 + num2;
        	else if(operator == '-' )
        		myresult = num1 - num2;
        	else if(operator == '*' )
        		myresult = num1 * num2;
        	else if(operator == '/' )
        		myresult = (float)num1 / num2;
        	System.out.println(" = " + myresult);
    }
}                                                       
class EEHandler extends Calculator implements EventHandler<ActionEvent>{
        @Override
    public void handle(ActionEvent e){
        System.out.println("\nClear");
        number = ""; 
    }
}