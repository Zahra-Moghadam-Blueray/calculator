package Calc;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.application.Application;
import javafx.beans.binding.Bindings;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.value.WritableObjectValue;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;


public class Calculator extends Application {
    public DoubleProperty value = new SimpleDoubleProperty();
    public static String number = "";
    public static double num1 , num2 , num3 , num4;
    public static double myresult;
    public static double myresultt;
    public static char operator;
    public String mathAct = "";
    int n = 0;
    Math math;
    //public static TextField Result; //= new TextField();
    public boolean operand1 = true;
    @Override
    public void start(Stage primaryStage) {
        FlowPane pane = new FlowPane();
        pane.setAlignment(Pos.CENTER);
        pane.setPadding(new Insets ( 70 , 3 ,70 , 3));//قاب ماشین حساب
        pane.setHgap(7);//fasele beyne dokme ha
        pane.setVgap(7);//fasele beyne dokme ha
      
       
        
        //TextField b = new TextField("input text");
        // 7 8 9
        Button nine = new Button("9");
        Button eight = new Button("8");
        Button seven = new Button("7");
        Button EE = new Button ("EE");
        
        
        
        seven.setStyle("-fx-background-color: #FFB6C1");
        eight.setStyle("-fx-background-color: #FFB6C1");
        nine.setStyle("-fx-background-color: #FFB6C1");
        EE.setStyle("-fx-background-color: #FF7000");
        
        
        

            seven.setMinSize(80, 80);
            eight.setMinSize(80, 80);
            nine.setMinSize(80, 80);
            EE.setMinSize(80, 80);
    //pane.getChildren().add(b);
    pane.getChildren().add(nine);
    nineHandler handler9 = new nineHandler();
        nine.setOnAction(handler9);
    pane.getChildren().add(eight);
        eightHandler handler8 = new eightHandler();
        eight.setOnAction(handler8);
    pane.getChildren().add(seven);
        sevenHandler handler7 = new sevenHandler();
        seven.setOnAction(handler7);
    pane.getChildren().add(EE);
        EEHandler handlerEE = new EEHandler();
        EE.setOnAction(handlerEE);
        
        //4 5 6

        
       Button six = new Button("6");
       Button five = new Button("5");
       Button four = new Button("4");
       Button devision = new Button("/");
        
        
       six.setStyle("-fx-background-color:#FFB6C1");
       five.setStyle("-fx-background-color:#FFB6C1");
       four.setStyle("-fx-background-color:#FFB6C1");
       devision.setStyle("-fx-background-color: #00CED1");
       
            six.setMinSize(80, 80);
            five.setMinSize(80, 80);
            four.setMinSize(80, 80);
            devision.setMinSize(80, 80);

    pane.getChildren().add(six);
        sixHandler handler6 = new sixHandler();
        six.setOnAction(handler6);
    pane.getChildren().add(five);
        fiveHandler handler5 = new fiveHandler();
        five.setOnAction(handler5);
    pane.getChildren().add(four);
        fourHandler handler4 = new fourHandler();
        four.setOnAction(handler4);
    pane.getChildren().add(devision);
        devisionHandler handlerdevision = new devisionHandler();
        devision.setOnAction(handlerdevision);

        Button three = new Button("3");
        Button two = new Button("2");
        Button one = new Button("1");
        Button minus = new Button ("-");

        
        three.setStyle("-fx-background-color: #FFB6C1");
        two.setStyle("-fx-background-color: #FFB6C1");
        one.setStyle("-fx-background-color: #FFB6C1");
        minus.setStyle("-fx-background-color: #00CED1 ");
       
        

            three.setMinSize(80, 80);
            two.setMinSize(80, 80);
            one.setMinSize(80, 80);
            minus.setMinSize(80, 80);

  
    pane.getChildren().add(three);
        threeHandler handler3 = new threeHandler();
        three.setOnAction(handler3);
    pane.getChildren().add(two);
        twoHandler handler2 = new twoHandler();
        two.setOnAction(handler2);
    pane.getChildren().add(one);
        oneHandler handler1 = new oneHandler();
        one.setOnAction(handler1);
    pane.getChildren().add(minus);
        minusHandler handlerminus = new minusHandler();
        minus.setOnAction(handlerminus);

        Button zero = new Button("0");
        Button plus = new Button("+");
        Button multiply = new Button("*");
        Button equal = new Button("=");

        
        
        zero.setStyle("-fx-background-color: #FFB6C1");
        plus.setStyle("-fx-background-color: #00CED1");
        multiply.setStyle("-fx-background-color: #00CED1");
        equal.setStyle("-fx-background-color:  #87cefa");
        

            zero.setMinSize(80, 80);
            plus.setMinSize(80, 80);
            multiply.setMinSize(80, 80);
            equal.setMinSize(80, 80);

            
            

  
    pane.getChildren().add(zero);
        zeroHandler handler0 = new zeroHandler();
        zero.setOnAction(handler0);
    pane.getChildren().add(plus);
        plusHandler handlerplus = new plusHandler();
        plus.setOnAction(handlerplus);
    pane.getChildren().add(multiply);
        multiplyHandler handlermultiply = new multiplyHandler();
        multiply.setOnAction(handlermultiply);
    pane.getChildren().add(equal);
        equalHandler handlerequal = new equalHandler();
        equal.setOnAction(handlerequal);
  

    Scene scene = new Scene(pane);
    primaryStage.setTitle("BlueRay Calculator");
    primaryStage.setScene(scene);
    primaryStage.show();
    }
    public static void main (String[] args) {
    	Application.launch(args);  
    }
}
class zeroHandler extends Calculator implements EventHandler<ActionEvent>{
        @Override
    public void handle(ActionEvent e){
        	number += "0";
        	System.out.print("0");
    }
}
class oneHandler extends Calculator implements EventHandler<ActionEvent>{
        @Override
    public void handle(ActionEvent e){
        number += "1";
        System.out.print("1");
    }
}           
class twoHandler extends Calculator implements EventHandler<ActionEvent>{
        @Override
    public void handle(ActionEvent e){
        	number += "2";
        	System.out.print("2");
    }   
}
class threeHandler extends Calculator implements EventHandler<ActionEvent>{
        @Override
    public void handle(ActionEvent e){
        	number += "3";
            System.out.print("3");
    }
}           
class fourHandler extends Calculator implements EventHandler<ActionEvent>{
        @Override
    public void handle(ActionEvent e){
        	number += "4";
            System.out.print("4");
    }
}
class fiveHandler extends Calculator implements EventHandler<ActionEvent>{
        @Override
    public void handle(ActionEvent e){
        	number += "5";
            System.out.print("5");
    }
}                   
class sixHandler extends Calculator implements EventHandler<ActionEvent>{
        @Override
    public void handle(ActionEvent e){
        	number += "6";
            System.out.print("6");
    }
}                       
class sevenHandler extends Calculator implements EventHandler<ActionEvent>{
        @Override
    public void handle(ActionEvent e){
        	number += "7";
            System.out.print("7");
    }
}                           
class eightHandler extends Calculator implements EventHandler<ActionEvent>{
        @Override
    public void handle(ActionEvent e){
        	number += "8";
            System.out.print("8");
    }
}                               
class nineHandler extends Calculator implements EventHandler<ActionEvent>{
        @Override
    public void handle(ActionEvent e){
        	number += "9";
            System.out.print("9");
    }
}                                   
class plusHandler extends Calculator implements EventHandler<ActionEvent>{
        @Override
    public void handle(ActionEvent e){
        num1 = Integer.parseInt(number);
        number = "";
        System.out.print("+");
        operator = '+';
    }
}                                       
class minusHandler extends Calculator implements EventHandler<ActionEvent>{
        @Override
    public void handle(ActionEvent e){
        	num1 = Integer.parseInt(number);
        	number = "";
        	System.out.print("-");
        	operator = '-';
    }
}                                           
class multiplyHandler extends Calculator implements EventHandler<ActionEvent>{
        @Override
    public void handle(ActionEvent e){
        System.out.print("*");
        num1 =  Integer.parseInt(number);
        number = "";
        operator = '*';
    }
}
class devisionHandler extends Calculator implements EventHandler<ActionEvent>{
        @Override
    public void handle(ActionEvent e){
        	num1 = Integer.parseInt(number);
        	number = "";
        	System.out.print("/");
        	operator = '/';
    }
} 

class plusHandler2 extends Calculator implements EventHandler<ActionEvent>{
    @Override
public void handle(ActionEvent e){
    num2 = Integer.parseInt(number);
    number = "";
    System.out.print("+");
    operator = '+';
}
}                                       
class minusHandler2 extends Calculator implements EventHandler<ActionEvent>{
    @Override
public void handle(ActionEvent e){
    	num2 = Integer.parseInt(number);
    	number = "";
    	System.out.print("-");
    	operator = '-';
}
}                                           
class multiplyHandler2 extends Calculator implements EventHandler<ActionEvent>{
    @Override
public void handle(ActionEvent e){
    System.out.print("*");
    num2 =  Integer.parseInt(number);
    number = "";
    operator = '*';
}
}
class devisionHandler2 extends Calculator implements EventHandler<ActionEvent>{
    @Override
public void handle(ActionEvent e){
    	num2 = Integer.parseInt(number);
    	number = "";
    	System.out.print("/");
    	operator = '/';
}
}

class plusHandler3 extends Calculator implements EventHandler<ActionEvent>{
    @Override
public void handle(ActionEvent e){
    num3 = Integer.parseInt(number);
    number = "";
    System.out.print("+");
    operator = '+';
}
}                                       
class minusHandler3 extends Calculator implements EventHandler<ActionEvent>{
    @Override
public void handle(ActionEvent e){
    	num3 = Integer.parseInt(number);
    	number = "";
    	System.out.print("-");
    	operator = '-';
}
}                                           
class multiplyHandler3 extends Calculator implements EventHandler<ActionEvent>{
    @Override
public void handle(ActionEvent e){
    System.out.print("*");
    num3 =  Integer.parseInt(number);
    number = "";
    operator = '*';
}
}
class devisionHandler3 extends Calculator implements EventHandler<ActionEvent>{
    @Override
public void handle(ActionEvent e){
    	num3 = Integer.parseInt(number);
    	number = "";
    	System.out.print("/");
    	operator = '/';
}
}
class equalHandler extends Calculator implements EventHandler<ActionEvent>{
        @Override
    public void handle(ActionEvent e){
        //System.out.print("=");
        	if (!mathAct.equals("")) {
        		num4 = Double.parseDouble(number);
        	number = "";
        	switch(mathAct)
        	{
        	case "+":
        		myresult = num1 + num2 + num3;
        		break;
        	case "-":
        		myresult = num1 - num2 - num3;
        		break;
        	case "*":
        		myresult = num1 * num2 * num3;
        		break;
        	case "/":
        		myresult = (float)num1 / num2 / num3;
        	System.out.println(" = " + myresult);
        		
        	}//switch end
        	
        	
        	}//end if
        	 num1 = 0;
             num2 = 0;
             mathAct = "";
             n = 0;
        	
    }//end of actionHandler
}                                                       
class EEHandler extends Calculator implements EventHandler<ActionEvent>{
        @Override
    public void handle(ActionEvent e){
        System.out.println("\nClear");
        number = ""; 
    }
}